import './App.css';
import Disperse from './components/Disperse';
  

function App() {
  return (
    <div >
      <Disperse/>
        
     </div>
  );
}

export default App;
